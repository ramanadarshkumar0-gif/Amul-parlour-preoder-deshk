from datetime import datetime, timedelta
import os
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, ForeignKey, Text
from sqlalchemy.orm import declarative_base, sessionmaker, Session

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./amul_parlour.db")
SECRET_KEY = os.getenv("SECRET_KEY", "change-this-development-secret-before-deployment")
ALGORITHM = "HS256"
ACCESS_TOKEN_MINUTES = 60 * 8

engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/token")

app = FastAPI(title="Amul Parlour Pre-Order Desk", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(80), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(30), default="staff", nullable=False)

class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), unique=True, nullable=False)
    price = Column(Float, nullable=False, default=0)
    stock = Column(Integer, nullable=False, default=0)

class Order(Base):
    __tablename__ = "orders"
    id = Column(Integer, primary_key=True, index=True)
    customer_name = Column(String(120), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    quantity = Column(Integer, nullable=False)
    total = Column(Float, nullable=False)
    status = Column(String(30), default="confirmed", nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class Complaint(Base):
    __tablename__ = "complaints"
    id = Column(Integer, primary_key=True, index=True)
    customer_name = Column(String(120), nullable=False)
    message = Column(Text, nullable=False)
    category = Column(String(40), default="general")
    status = Column(String(30), default="open")
    created_at = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_token(username: str, role: str):
    expires = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_MINUTES)
    return jwt.encode({"sub": username, "role": role, "exp": expires}, SECRET_KEY, algorithm=ALGORITHM)

def current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    error = HTTPException(status_code=401, detail="Invalid or expired login token", headers={"WWW-Authenticate": "Bearer"})
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if not username:
            raise error
    except JWTError:
        raise error
    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise error
    return user

def require_admin(user=Depends(current_user)):
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user

class UserCreate(BaseModel):
    username: str = Field(min_length=3, max_length=80)
    password: str = Field(min_length=8)
    role: str = "staff"

class ProductCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    price: float = Field(ge=0)
    stock: int = Field(ge=0)

class OrderCreate(BaseModel):
    customer_name: str
    product_id: int
    quantity: int = Field(gt=0)

class ComplaintCreate(BaseModel):
    customer_name: str
    message: str

@app.get("/")
def root():
    return {"message": "Amul Parlour Pre-Order Desk API", "docs": "/docs", "health": "/health"}

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/setup/admin")
def setup_admin(data: UserCreate, db: Session = Depends(get_db)):
    if db.query(User).count() > 0:
        raise HTTPException(status_code=403, detail="Setup is already complete")
    user = User(username=data.username, password_hash=get_password_hash(data.password), role="admin")
    db.add(user); db.commit()
    return {"message": "Admin created. Please sign in at /docs using /token."}

@app.post("/users", status_code=201)
def create_user(data: UserCreate, db: Session = Depends(get_db), admin=Depends(require_admin)):
    if data.role not in ("admin", "staff"):
        raise HTTPException(status_code=400, detail="Role must be admin or staff")
    if db.query(User).filter(User.username == data.username).first():
        raise HTTPException(status_code=409, detail="Username already exists")
    user = User(username=data.username, password_hash=get_password_hash(data.password), role=data.role)
    db.add(user); db.commit()
    return {"id": user.id, "username": user.username, "role": user.role}

@app.post("/token")
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.username == form.username).first()
    if not user or not verify_password(form.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Incorrect username or password")
    return {"access_token": create_token(user.username, user.role), "token_type": "bearer", "role": user.role}

@app.get("/me")
def me(user=Depends(current_user)):
    return {"username": user.username, "role": user.role}

@app.post("/products", status_code=201)
def add_product(data: ProductCreate, db: Session = Depends(get_db), user=Depends(current_user)):
    if db.query(Product).filter(Product.name == data.name).first():
        raise HTTPException(status_code=409, detail="Product already exists")
    product = Product(**data.model_dump())
    db.add(product); db.commit(); db.refresh(product)
    return product_out(product)

def product_out(p):
    return {"id": p.id, "name": p.name, "price": p.price, "stock": p.stock}

@app.get("/products")
def list_products(db: Session = Depends(get_db), user=Depends(current_user)):
    return [product_out(p) for p in db.query(Product).order_by(Product.name).all()]

@app.post("/orders", status_code=201)
def create_order(data: OrderCreate, db: Session = Depends(get_db), user=Depends(current_user)):
    product = db.query(Product).filter(Product.id == data.product_id).with_for_update().first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    if product.stock < data.quantity:
        raise HTTPException(status_code=409, detail="Not enough stock")
    product.stock -= data.quantity
    order = Order(customer_name=data.customer_name, product_id=product.id, quantity=data.quantity, total=product.price * data.quantity)
    db.add(order); db.commit(); db.refresh(order)
    return order_out(order, product.name)

def order_out(o, product_name=None):
    return {"id": o.id, "customer_name": o.customer_name, "product_id": o.product_id, "product_name": product_name, "quantity": o.quantity, "total": o.total, "status": o.status, "created_at": o.created_at.isoformat() if o.created_at else None}

@app.get("/orders")
def list_orders(db: Session = Depends(get_db), user=Depends(current_user)):
    rows = db.query(Order, Product.name).join(Product, Order.product_id == Product.id).order_by(Order.created_at.desc()).all()
    return [order_out(o, name) for o, name in rows]

@app.post("/complaints", status_code=201)
def create_complaint(data: ComplaintCreate, db: Session = Depends(get_db), user=Depends(current_user)):
    msg = data.message.lower()
    category = "billing" if any(x in msg for x in ["bill", "payment", "price", "refund"]) else "product" if any(x in msg for x in ["melt", "damage", "quality", "expired"]) else "delivery" if any(x in msg for x in ["late", "delivery", "order"]) else "general"
    item = Complaint(customer_name=data.customer_name, message=data.message, category=category)
    db.add(item); db.commit(); db.refresh(item)
    return {"id": item.id, "customer_name": item.customer_name, "message": item.message, "category": item.category, "status": item.status}

@app.get("/complaints")
def list_complaints(db: Session = Depends(get_db), user=Depends(current_user)):
    return [{"id": c.id, "customer_name": c.customer_name, "message": c.message, "category": c.category, "status": c.status, "created_at": c.created_at.isoformat()} for c in db.query(Complaint).order_by(Complaint.created_at.desc()).all()]

@app.get("/analytics")
def analytics(db: Session = Depends(get_db), admin=Depends(require_admin)):
    from sqlalchemy import func
    order_count = db.query(func.count(Order.id)).scalar() or 0
    revenue = db.query(func.coalesce(func.sum(Order.total), 0)).scalar() or 0
    stock_units = db.query(func.coalesce(func.sum(Product.stock), 0)).scalar() or 0
    open_complaints = db.query(func.count(Complaint.id)).filter(Complaint.status == "open").scalar() or 0
    return {"order_count": order_count, "revenue": round(float(revenue), 2), "stock_units": stock_units, "open_complaints": open_complaints}

@app.patch("/products/{product_id}/stock")
def adjust_stock(product_id: int, amount: int, db: Session = Depends(get_db), admin=Depends(require_admin)):
    product = db.query(Product).filter(Product.id == product_id).first()
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    if product.stock + amount < 0:
        raise HTTPException(status_code=409, detail="Stock cannot become negative")
    product.stock += amount; db.commit(); db.refresh(product)
    return product_out(product)
