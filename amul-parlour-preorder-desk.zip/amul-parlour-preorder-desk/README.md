# Amul Parlour Pre-Order Desk

A starter FastAPI application for a parlour's pre-orders, stock, complaints, and sales analytics.

## Features
- JWT login with admin/staff roles
- SQLite database via SQLAlchemy
- Product inventory and stock validation during order creation
- Orders list and totals
- Rule-based complaint category triage (billing, product, delivery, general)
- Admin analytics endpoint
- Interactive API documentation at `/docs`
- Health check at `/health`

## Run locally
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

Open http://127.0.0.1:8000/docs

## First-time setup
1. Open `POST /setup/admin` in Swagger docs.
2. Enter a username and a password of at least 8 characters. This endpoint only works while no users exist.
3. Click `Authorize` in Swagger and sign in through `/token` using the admin username and password.
4. Create products through `POST /products`, then create orders through `POST /orders`.

## Important security notes
- This is a starter project, not production-ready.
- Set a strong random `SECRET_KEY` environment variable before deployment.
- The first-admin setup endpoint is intentionally locked after the first account is created.
- Use HTTPS and restrict CORS before exposing this app publicly.
- Never commit real customer data, passwords, or secrets to GitHub.

## API overview
- `GET /health`
- `POST /setup/admin`
- `POST /token`
- `GET /me`
- `POST /users` (admin)
- `GET/POST /products`
- `GET/POST /orders`
- `GET/POST /complaints`
- `GET /analytics` (admin)
- `PATCH /products/{product_id}/stock` (admin)

## Tests
```bash
pytest
```
